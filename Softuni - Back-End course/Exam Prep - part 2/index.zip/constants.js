exports.SECRET = 'Secret';

exports.paymentMethodsMap = {
    "crypto-wallet": "Crypto Wallet",
    "credit-card": "Credit Card",
    "debit-card": "Debit Card",
    "paypal": "payPal"
};